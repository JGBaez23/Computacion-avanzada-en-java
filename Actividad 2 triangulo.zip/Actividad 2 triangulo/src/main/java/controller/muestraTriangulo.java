package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Calculo.Triangulo;

@WebServlet("/muestraTriangulo")
public class muestraTriangulo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public muestraTriangulo() {
        super();
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException{
    	response.setContentType("text/html;charset=UTF-8");
    	String b = request.getParameter("base");
    	String a = request.getParameter("altura");
    	Triangulo t = new Triangulo(b, a);
    	t.hacerPerimetro();
    	t.hacerArea();
    	request.setAttribute("tri", t);
    	request.getRequestDispatcher("/Ejemplo.jsp").forward(request, response);
    	
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	public String getServletInfo() {
		return " ";
		
	}

}
