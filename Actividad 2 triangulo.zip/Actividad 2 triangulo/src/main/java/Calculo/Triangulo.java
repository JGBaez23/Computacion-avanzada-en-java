package Calculo;



public class Triangulo {
	private int base;
	private int altura;
	private int area;
	private int perimetro;
	
	public Triangulo(String base, String altura) {
		this.setBase(Integer.parseInt(base));
		this.setAltura(Integer.parseInt(altura));
		
		
	}
	
	public void hacerPerimetro() {
		int p = this.getBase() * 3;
		this.setPerimetro(p);
	}
	public void hacerArea() {
		int a = (this.getBase() * this.getAltura()) / 2;
		this.setArea(a);
	}

	public int getBase() {
		return base;
	}

	public void setBase(int base) {
		this.base = base;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getArea() {
		return area;
	}

	public void setArea(int area) {
		this.area = area;
	}

	public int getPerimetro() {
		return perimetro;
	}

	public void setPerimetro(int perimetro) {
		this.perimetro = perimetro;
	}
	
	
}


